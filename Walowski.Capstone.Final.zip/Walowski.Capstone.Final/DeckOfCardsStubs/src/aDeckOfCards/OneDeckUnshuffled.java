package aDeckOfCards;
// the code that was used here was the code that we worked on together in class with you I rewrote some of the commented stubs. 
public class OneDeckUnshuffled 
{
	public OneDeckUnshuffled() //Constructor
	{
		String[] theDeck = makeDeckArray();
		theDeck=initializeDeck(theDeck);
		theDeck=addCardNumberToDeckString(theDeck);
		theDeck=addFaceNameToDeckString(theDeck);
		theDeck=addAceToDeckString(theDeck);
		theDeck=addSuitToDeckString(theDeck);
		
		returnTheDeck(theDeck);
	}
	
	public String[] addSuitToDeckString(String[] theDeck)
	{
		//Add the word 'suite' to every card number
		//1-13 clubs
		//14-26 diamonds
		//27-39 hearts
		//40-52 spades
		
	}
	
	public String[] addAceToDeckString(String[] theDeck)
	{
		//If a card is going to become an ace, attach the term 'ace' to it.

	}
	public String[] addFaceNameToDeckString(String[] theDeck)
	{
		//Attach the corresponding face name to every card that will eventually become a face card
	
	}
	
	public String[] addCardNumberToDeckString(String[] theDeck)
	{
		
		//Include the card number for numbered cards
		// card[0] will contain "1"
		// card[2] will contain "2 2"
		// card[10] will contain "11"
		// card[14] will contain "14 2"
		
	}
	
	public String[] makeDeckArray()
	{
		
	}
	
	public String[] initializeDeck(String[] theDeck)
	{
		//assign numeric(toString()) value to each card 
		//card numbers are 1 to 52
		
		//for loop
		// inside the () are three parts separated by semicolons
		//The first part declares and initializes variables
		//The second part contains the conditional statement
		//The third part increments variables of my choice  
	
	}
	
	public String[] returnTheDeck(String[] theDeck)
	{
		
	}
}
