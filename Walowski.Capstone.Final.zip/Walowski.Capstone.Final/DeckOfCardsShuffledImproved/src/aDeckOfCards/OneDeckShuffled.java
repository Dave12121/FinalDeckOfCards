package aDeckOfCards;

public class OneDeckShuffled 
{
	public OneDeckShuffled()
	{
		String[] theDeck = makeDeckArray();
		theDeck=initializeDeck(theDeck);
		theDeck=addCardNumberToDeckString(theDeck);
		theDeck=addFaceNameToDeckString(theDeck);
		theDeck=addAceToDeckString(theDeck);
		theDeck=addSuitToDeckString(theDeck);
		theDeck=shuffleTheDeck(theDeck);
		
		//returnTheDeck(theDeck);
	}

	public String[] addSuitToDeckString(String[] theDeck)
	{
		
		for(int n = 0; n < theDeck.length; n++)
		{
			if(n/13==0)
			{
				theDeck[n]+="clubs";
			}
			else if(n/13==1)
			{
				theDeck[n]+="diamonds";
			}
			else if(n/13==2)
			{
				theDeck[n]+="hearts";
			}
			else if(n/13==3)
			{
				theDeck[n]+="spades";
			}
			
		}
		return theDeck;
		
	}
	
	public String[] addAceToDeckString(String[] theDeck)
	{
		
	for(int n = 0; n < theDeck.length; n++)
	{
		if(theDeck[n].equals(" 1 "))
		{
			theDeck[n] = "ace";
		}
	}
	return theDeck;
	}
	public String[] addFaceNameToDeckString(String[] theDeck)
	{
		
		for(int n = 0; n < theDeck.length; n++)
		{
			if(theDeck[n].equals(" 11 "))
			{
				theDeck[n] = "jack";
			}
			else if(theDeck[n].equals(" 12 "))
			{
				theDeck[n] = "queen";
			}
			else if(theDeck[n].equals(" 0 "))
			{
				theDeck[n] = "king";
			}
		}
		
		return theDeck;
	}
	
	public String[] addCardNumberToDeckString(String[] theDeck)
	{
		int theCard;
		
		
		for(int n = 0; n < theDeck.length;n++)
		{
			theCard = Integer.parseInt(theDeck[n])%13;
			theDeck[n] = String.valueOf(theCard);
		}
		return theDeck;
	}
	
	public String[] makeDeckArray()
	{
		String[] theDeck= new String[52];
		
		return theDeck;
	}
	
	public String[] initializeDeck(String[] theDeck)
	{

		for(int n = 0; n < theDeck.length;n++)
		{
			theDeck[n] = String.valueOf(n + 1); 
		}
		
		return theDeck;
	}
	
	//public String[] returnTheDeck(String[] theDeck)
	{
		//for(int n = 0; n < theDeck.length;n++)
		{
			//System.out.print(theDeck[n] + " ");
			
			//if(n%13==0);
				
		}
		//return theDeck;
	}
	
	public String[] shuffleTheDeck(String[] theDeck)
	{
		String[] theShuffledDeckOfCards = new String[theDeck.length];
		
		for (int n=0; n < theDeck.length; n++)
		{
			int index = (int) (Math.random() * theDeck.length);
			
			while (theDeck[index] == "-1")
			{
				index++;
				if (index == theDeck.length)
					index = 0;
			}
			theShuffledDeckOfCards[n] = theDeck[index];
			theDeck[index] = "-1";
			
			//System.out.print(theShuffledDeckOfCards[n] + ", ");
			//if (n % 5== 0 && n>0)
			//System.out.println();
			}
		return theShuffledDeckOfCards;
		}
	}
